jQuery(document).ready(function($) {
  $('[data-toggle="tooltip"]').tooltip();
});
